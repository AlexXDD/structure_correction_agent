package net;

import java.util.*;

public class Conceptor extends NetNode {
	public String node1;
	public String node2;
	public ArrayList<NetNode> receptors;
	public Integer Node_Type = 1;
	public int activated = 0;
	
	public Set<NetNode> receptorSet = new HashSet<>();
	public ArrayList<NetNode> receptorList = new ArrayList<NetNode>();
	
	public Conceptor(String node1, String node2, ArrayList<NetNode> receptors)
    {
        this.node1 = node1;
        this.node2 = node2;
        this.receptors = receptors;
    }
	
	public Conceptor setNode2(String node2) {
        this.node2 = node2;
        return this;
    }
	public String getNode2(){
		return this.node2;
	}

    public Conceptor setNode1(String node1) {
        this.node1 = node1;
        return this;
    }
    public String getNode1(){
        return this.node1;
    }

	public Conceptor setReceptors(ArrayList<NetNode> receptorList) {
        this.receptorList = receptorList;
        return this;
    }
	public ArrayList<NetNode> getReceptors() {
        return this.receptorList;
    }
	public Conceptor setReceptorSet(Set<NetNode> receptorSet) {
        this.receptorSet = receptorSet;
        return this;
    }
	public Set<NetNode> getReceptorSet() {
        return this.receptorSet;
    }
	public Conceptor setReceptorList(ArrayList<NetNode> receptorList) {
        this.receptorList = receptorList;
        return this;
    }
	public ArrayList<NetNode> getReceptorList() {
        return this.receptorList;
    }
	public void setActive(){
		this.activated = 1;
	}
	public void setInactive(){
		this.activated = 0;
	}
}
