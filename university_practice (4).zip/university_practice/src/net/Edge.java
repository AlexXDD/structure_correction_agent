package net;

public class Edge {
    public String guid;

    private String node1;
    private String node2;
    private String group;
    private String edgeName;
    private String isTwoWay = "false";

    public Edge(String guid, String node1, String node2, String group, String edgeName, String isTwoWay) {
        this.group = group;
        this.guid = guid;
        this.node1 = node1;
        this.node2 = node2;
        this.edgeName = edgeName;
        this.isTwoWay = isTwoWay;
    }

    public Edge(String guid, String node1, String node2, String edgeName) {
        this.guid = guid;
        this.node1 = node1;
        this.node2 = node2;
        this.edgeName = edgeName;
        this.group = "Part_of";
        this.isTwoWay = "false";
    }

    public Edge(String guid, String node1, String node2) {
        this.group = "Part_of";
        this.guid = guid;
        this.node1 = node1;
        this.node2 = node2;
    }

    public String getGuid() {
        return this.guid;
    }

    public Edge setGuid(String guid) {
        this.guid = guid;
        return this;
    }

    public String getNode1() {
        return this.node1;
    }

    public Edge setNode1(String node1) {
        this.node1 = node1;
        return this;
    }

    public String getNode2() {
        return node2;
    }

    public Edge setNode2(String node2) {
        this.node2 = node2;
        return this;
    }

    public String getGroup() {
        return this.group;
    }

    public Edge setGroup(String group) {
        this.group = group;
        return this;
    }

    public String getEdgeName() {
        return this.edgeName;
    }

    public Edge setEdgeName(String edgeName) {
        this.edgeName = edgeName;
        return this;
    }

    public String getIsTwoWay() {
        return this.isTwoWay;
    }

    public Edge setIsTwoWay(String isTwoWay) {
        this.isTwoWay = isTwoWay;
        return this;
    }
}
