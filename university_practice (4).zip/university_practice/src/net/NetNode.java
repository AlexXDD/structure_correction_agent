package net;

import org.w3c.dom.*;

import java.util.*;

public class NetNode implements org.w3c.dom.Node { //implements NetNode{
	public Integer node_index;

	public String node_guid;
	public String node_name;
	public String nClass;// shape="square" color="80" xPos="31" yPos="196" font="Verdana" fontsize="14"
	public String shape;
	public String color;
	public String xPos;
	public String yPos;
	public String font;
	public String fontsize;

	private int activated = 0; //default value = 0

	public Integer Node_Type; // 0 ? Receptor;1 ? Conceptor; 2 ? Class

	public Set<NetNode> receptorSet = new HashSet<>();
	/* set of Node_index.
	 * ????????? ?? ????? ????? ??????? ? ???????? ?????.
	 * ??? ???????? ???????? ???????? ????? ?? ?????????.
	 * ??? ????????????? ????? ???????????? 1 ??? ???????? ?????.
	 * ??? ????????? ?? ???????*/
	//----------//
	public ArrayList<NetNode> receptorList = new ArrayList<>();
	/* ????????? ????????? Receptor_set.
	 *  ??????? ??? ?????????? ??????? ?? ?????? ?????????
	 *  ?? ????????? ????? ??????? ????????? ???????? ?????.
	 *  ??? ????????? ?? ???????*/
	//----------//
	/* ???????? ??????? ??????? ????????? ? ?????? Receptor_list.
	 * ???? ????????? ?????????? ????? ? ???????? ?????,
	 * ???? ?????? ? ????????? ???? ???????????, ?? ??????? ?? Receptorlist.Count
	 * ?????? ??????? ????????? ?????? ??????????.
	 * Receptorlist ?? Receptorset ??? ????? ?? ?????????*/
	//----------//
	public ArrayList<NetNode> conceptorList = new ArrayList<>();
	/* ????????? ???????? ??? ?????????.
	 * ?????? ?????? ????? ? ????? ???????? ????????.*/
	//----------//
	private Set<NetNode> downNodeSet = new HashSet<>();
	/*downNodeSet: set of node_index.
	 * ??????? NetNode ? ?????????? ????????? ?????,
	 * ? ????? ???????? ????? ????????????? ??????.
	 * only for class nodes*/
	public Set<NetNode> upperNodeSet = new HashSet<>();
	/*upperNodeSet: set of node_index.
	 * ??????? NetNode ? ???????????? ????????? ?????,
	 * ? ????? ???????? ????? ????????????? ??????.
	 * for elements whose name doesn't start with $ and aren't receptors*/
	//----------//
	public NetNode() {}
	public NetNode(String node_name, String node_guid, Integer NodeType){
		this.node_name = node_name;
		this.node_guid = node_guid;
		this.Node_Type = NodeType;
	}
	public NetNode(String node_name, String node_guid, String nClass, Integer index, String shape, String color, String xPos, String yPos, String font, String fontsize){
		this.node_name = node_name;
		this.node_guid = node_guid;
		this.nClass = nClass;
		this.node_index = index;
		this.shape = shape;
		this.color = color;
		this.xPos = xPos;
		this.yPos = yPos;
		this.font = font;
		this.fontsize = fontsize;
	}
	public NetNode(String node_name, String node_guid, Integer NodeType, ArrayList<NetNode> conc_list, String shape, String color, String xPos, String yPos, String font, String fontsize){
		this.node_name = node_name;
		this.node_guid = node_guid;
		this.Node_Type = NodeType;
		this.conceptorList = conc_list;
		this.shape = shape;
		this.color = color;
		this.xPos = xPos;
		this.yPos = yPos;
		this.font = font;
		this.fontsize = fontsize;
	}
	public NetNode(String node_name, String node_guid, Integer NodeType, ArrayList<NetNode> rec_list, HashSet<NetNode> rec_set){
		this.node_name = node_name;
		this.node_guid = node_guid;
		this.Node_Type = NodeType;
		this.receptorList = rec_list;
		this.receptorSet = rec_set;
	}

	public void activate() {
		this.activated = 1;
	}

	public void deactivate() {
		this.activated = 0;
	}

	public void increaseActivation() {
		activated++;
	}

	public void addDownNode(NetNode netNode) {
		downNodeSet.add(netNode);
	}

	public void addUpperNode(NetNode netNode) {
		upperNodeSet.add(netNode);
	}

	public NetNode getNode(String Name, Set<NetNode> set){
		NetNode res = new NetNode();
		for (NetNode s : set) {
			if(s.node_name.equals(Name))
			{ res = s;}
		}
		return res;
	}
	public NetNode getNode(Integer Node_index, Set<NetNode> set){
		NetNode res = new NetNode();
		for (NetNode s : set) {
			if(s.node_index.equals(Node_index))
			{ res = s;}
		}
		return res;
	}

	public Integer getNodeLevel() {
		return receptorList.size();
	}
	//----------//
	public NetNode setGuid(String node_guid) {
		this.node_guid = node_guid;
		return this;
	}
	public String getGuid(){
		return this.node_guid;
	}
	public NetNode setNodeName(String node_name) {
		this.node_name = node_name;
		return this;
	}
	public String getNodeName(){
		return this.node_name;
	}

	public NetNode setNodeIndex(Integer node_index) {
		this.node_index = node_index;
		return this;
	}
	public Integer getNodeIndex(){
		return this.node_index;
	}
	public NetNode setNodeType(Integer node_type) {
		this.Node_Type = node_type;
		return this;
	}
	public Integer getNode_Type(){
		return this.Node_Type;
	}
	public String getNClass() {
		return nClass;
	}

	public NetNode setNClass(String nclass) {
		this.nClass = nclass;
		return this;
	}
	public void setActive(){
		this.activated = 1;
	}
	public void setInactive(){
		this.activated = 0;
	}
	public NetNode setConceptors(ArrayList<NetNode> conceptorList) {
		this.conceptorList = conceptorList;
		return this;
	}
	public ArrayList<NetNode> getConceptors() {
		return this.conceptorList;
	}
	public NetNode setReceptors(ArrayList<NetNode> receptorList) {
		this.receptorList = receptorList;
		return this;
	}
	public ArrayList<NetNode> getReceptors() {
		return this.receptorList;
	}
	public NetNode setReceptorSet(Set<NetNode> receptorSet) {
		this.receptorSet = receptorSet;
		return this;
	}
	public Set<NetNode> getReceptorSet() {
		return this.receptorSet;
	}

	public int getActivationLevel() {
		return activated;
	}

	public Set<NetNode> getDownNodeSet() {
		return downNodeSet;
	}

	public Set<NetNode> getUpperNodeSet() {
		return upperNodeSet;
	}

	@Override
	public String getNodeValue() throws DOMException {
		return null;
	}

	@Override
	public void setNodeValue(String nodeValue) throws DOMException {

	}

	@Override
	public short getNodeType() {
		return 0;
	}

	@Override
	public org.w3c.dom.Node getParentNode() {
		return null;
	}

	@Override
	public NodeList getChildNodes() {
		return null;
	}

	@Override
	public org.w3c.dom.Node getFirstChild() {
		return null;
	}

	@Override
	public org.w3c.dom.Node getLastChild() {
		return null;
	}

	@Override
	public org.w3c.dom.Node getPreviousSibling() {
		return null;
	}

	@Override
	public org.w3c.dom.Node getNextSibling() {
		return null;
	}

	@Override
	public NamedNodeMap getAttributes() {
		return null;
	}

	@Override
	public Document getOwnerDocument() {
		return null;
	}

	@Override
	public org.w3c.dom.Node insertBefore(org.w3c.dom.Node newChild, org.w3c.dom.Node refChild) throws DOMException {
		return null;
	}

	@Override
	public org.w3c.dom.Node replaceChild(org.w3c.dom.Node newChild, org.w3c.dom.Node oldChild) throws DOMException {
		return null;
	}

	@Override
	public org.w3c.dom.Node removeChild(org.w3c.dom.Node oldChild) throws DOMException {
		return null;
	}

	@Override
	public org.w3c.dom.Node appendChild(org.w3c.dom.Node newChild) throws DOMException {
		return null;
	}

	@Override
	public boolean hasChildNodes() {
		return false;
	}

	@Override
	public org.w3c.dom.Node cloneNode(boolean deep) {
		return null;
	}

	@Override
	public void normalize() {

	}

	@Override
	public boolean isSupported(String feature, String version) {
		return false;
	}

	@Override
	public String getNamespaceURI() {
		return null;
	}

	@Override
	public String getPrefix() {
		return null;
	}

	@Override
	public void setPrefix(String prefix) throws DOMException {

	}

	@Override
	public String getLocalName() {
		return null;
	}

	@Override
	public boolean hasAttributes() {
		return false;
	}

	@Override
	public String getBaseURI() {
		return null;
	}

	@Override
	public short compareDocumentPosition(org.w3c.dom.Node other) throws DOMException {
		return 0;
	}

	@Override
	public String getTextContent() throws DOMException {
		return null;
	}

	@Override
	public void setTextContent(String textContent) throws DOMException {

	}

	@Override
	public boolean isSameNode(org.w3c.dom.Node other) {
		return false;
	}

	@Override
	public String lookupPrefix(String namespaceURI) {
		return null;
	}

	@Override
	public boolean isDefaultNamespace(String namespaceURI) {
		return false;
	}

	@Override
	public String lookupNamespaceURI(String prefix) {
		return null;
	}

	@Override
	public boolean isEqualNode(org.w3c.dom.Node arg) {
		return false;
	}

	@Override
	public Object getFeature(String feature, String version) {
		return null;
	}

	@Override
	public Object setUserData(String key, Object data, UserDataHandler handler) {
		return null;
	}

	@Override
	public Object getUserData(String key) {
		return null;
	}



}
