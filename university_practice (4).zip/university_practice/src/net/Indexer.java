package net;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Indexer {

    private int lastIndex;
    private HashMap<Integer,List<NetNode>> listOfNodes;

    public Indexer() {
        listOfNodes = new HashMap<Integer,List<NetNode>>();
        lastIndex = -1;
    }

    public void AddNode(int level, NetNode netNode) {
        if (lastIndex < level) {
            lastIndex = level;
        }
        if(listOfNodes.containsKey(level)){
            listOfNodes.get(level).add(netNode);
        }else {

            ArrayList newArray = new ArrayList();
            newArray.add(netNode);

            listOfNodes.put(level, newArray );
        }
    }

    public void removeNode(int level, NetNode node) {
        listOfNodes.remove(level, node);


    }

    public void setListOfNodeByLevel(int level, List<NetNode> listOfNodes) {
        if (lastIndex < level) {
            lastIndex = level;
        }
        this.listOfNodes.put(level, listOfNodes);
    }

    public List<NetNode> GetListOfNodesByLevels(int level)
    {
        // ToDo: Add check if level exists in listOfNodes.

        return listOfNodes.get(level);
    }

    public int getLastIndex() {
        return lastIndex;
    }
}