package net;

import java.util.ArrayList;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;

public class NetReader {
    @SuppressWarnings({ "unchecked", "rawtypes" })

    public static String fullPathToInputFile = "graph2.xml";

    public static void readConceptors(ArrayList<Conceptor> conceptorslist, HashMap<String, NetNode> nodesList) {
        try {
            Reader reader =  new InputStreamReader( new FileInputStream(fullPathToInputFile),"Windows-1251");
            InputSource is = new InputSource(reader);
            is.setEncoding("Windows-1251");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(is);

            doc.getDocumentElement().normalize();

            System.out.println("Root element :"
                    + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("Conceptor");
            System.out.println("----------------------------");
            //----------------//

            ArrayList<NetNode> node2list = new ArrayList<NetNode>();
            int i;

            for (int temp = 0; temp < nList.getLength(); temp++) {

                org.w3c.dom.Node nNode = nList.item(temp);

                Element eElement;
                String node1String;
                String node2String;

                // System.out.println("\nCurrent Element :"+ nNode.getNodeName());
                if (nNode.getNodeType() == NetNode.ELEMENT_NODE) {
                    eElement = (Element) nNode;
                    node1String = eElement.getAttribute("node1");
                    node2String = eElement.getAttribute("node2");

                    // NetNode node1 = nodesList.get(node1String);

                    i = temp;

                    String nodeString;
                    NetNode node;

                    while (eElement.getAttribute("node1").equals(node1String)) {

                        nodeString = eElement.getAttribute("node2");
                        node = nodesList.get(nodeString);

                        node2list.add(node);

                        i++;
                        temp = i;
                        if (temp < nList.getLength()) {
                            nNode = nList.item(i);
                            eElement = (Element) nNode;
                        } else {
                            break;
                        }
                    }

                    temp -= 1;

                    nodesList.get(node1String).setReceptors(node2list);

                    conceptorslist.add(new Conceptor(node1String, node2String, new ArrayList(node2list)));
                    node2list.clear();

                }
            }

            System.out.println();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //NetNode tmp_n = null;
    //------------------------------readConceptors-----------------------------------//
    @SuppressWarnings("unused")
    public static void readNodes(HashMap<String, NetNode> nodeslist) {
        Integer index = 0;

        try {
            File inputFile = new File(fullPathToInputFile);
            DocumentBuilderFactory dbFactory
                    = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :"
                    + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("Node");
            System.out.println("----------------------------");


            for (int temp = 0; temp < nList.getLength(); temp++) {

                org.w3c.dom.Node nNode = nList.item(temp);

                //Net p = Net.getInstance( );

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String guid = eElement.getAttribute("guid");
                    String nodeName = eElement.getAttribute("nodeName");
                    String nclass = eElement.getAttribute("nclass");
                    String shape = eElement.getAttribute("shape");
                    String color = eElement.getAttribute("color");
                    String xPos = eElement.getAttribute("xPos");
                    String yPos = eElement.getAttribute("yPos");
                    String font = eElement.getAttribute("font");
                    String fontSize = eElement.getAttribute("fontsize");

                    nodeslist.put(nodeName, new NetNode(nodeName, guid, nclass, index, shape, color, xPos, yPos, font, fontSize));

                    index++;
                    //-------------------------------//
                    //if(nodeName.startsWith("$")){}
                    /*if(!nodeName.contains("Class") && !nodeName.startsWith("$")){
                        int size = nodeslist.size();
                        NetNode node = nodeslist.get(size - 1);
                        node.downNodeSet.add(null);
                    }*/
                    //Node temp_n = nNode;
                    //---------------------------------//
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //-------------------------------readNodes---------------------------------------//
    public static void readEdges(ArrayList<Edge> edgeslist, String tagName) {
        try {
            File inputFile = new File(fullPathToInputFile);
            DocumentBuilderFactory dbFactory
                    = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :"
                    + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName(tagName);
            System.out.println("----------------------------");

            //----------------//

            for (int temp = 0; temp < nList.getLength(); temp++) {
                org.w3c.dom.Node nNode = nList.item(temp);

                System.out.println("\nCurrent Element :"+ nNode.getNodeName());
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;

                    String guid = eElement.getAttribute("guid");
                    String group = eElement.getAttribute("group");
                    String node1 = eElement.getAttribute("node1");
                    String node2 = eElement.getAttribute("node2");
                    String edgeName = eElement.getAttribute("edgeName");
                    String isTwoWay = eElement.getAttribute("istwoway");

                    edgeslist.add(new Edge(guid, node1, node2, group, edgeName, isTwoWay));
                }
            }
            /*for (int temp = 0; temp < edgeslist.size(); temp++) {
                System.out.println("Guid : "+edgeslist.get(temp).getGuid()+" node1 : "+edgeslist.get(temp).getNode1()
                        +" node2 : "+edgeslist.get(temp).getNode2()+" group : "+edgeslist.get(temp).getGroup());
            }*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //-------------------------------readEdges---------------------------------------//
}