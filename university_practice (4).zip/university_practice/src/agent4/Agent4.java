package agent4;

import byteZipArchiver.ByteZipArchiver;
import jade.core.AID;
import jade.lang.acl.ACLMessage;

import java.io.IOException;


public class Agent4 extends AgentBase {
    private static final String INPUT_FILE_PATH = "files\\input.xml";
    private static final String OUTPUT_FILE_PATH = "files\\output.xml";

    //FOR DEBUGGING ONLY
    public static void main(String[] args) {

        NetProcessor.processNetwork();
    }

    protected void setup() {
        AID id = new AID("agent4", AID.ISLOCALNAME);

        /*  RECEIVING NETWORK   */
        blockingReceive(); //Blocks agent until the message appear in queue
         //Receives message
        ACLMessage msg = receive(); //Receiving message
        if (msg != null) {
            //Message processing
            byte[] content = msg.getByteSequenceContent(); //Getting message content
            try {
                ByteZipArchiver.UnzipBytes(content, INPUT_FILE_PATH); //Unzip content to Input.xml
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        /*-------------------------------------*/



        //TODO All network processing stuff
        NetProcessor.processNetwork();


        /*  SENDING RESULTED NETWORK    */
        byte[] result;
        try {
            result = ByteZipArchiver.ZipBytes(OUTPUT_FILE_PATH);
            ReplyFiles(msg, result); //Sending network to coordinator
        } catch (IOException e) {
            e.printStackTrace();
        }



        doDelete(); // Termination method. Calls takeDown() method
    }

    protected void takeDown() {

    }
}