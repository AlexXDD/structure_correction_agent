package agent4;

import net.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.*;

import static java.util.UUID.randomUUID;

public class NetProcessor {
    public static void processNetwork() {
        //<<------------------ step1

        NetReader.fullPathToInputFile = "graph2.xml";

        HashMap<String, NetNode> nodeslist = new HashMap<>();
        NetReader.readNodes(nodeslist);

        ArrayList<Conceptor> conceptorslist = new ArrayList<>();
        NetReader.readConceptors(conceptorslist, nodeslist);

        Map<String, String> stringsToDelete = new HashMap<>();

        for (int i = 0; i < conceptorslist.size(); i++) {
            for (int j = 0; (i != j) && j < conceptorslist.size(); j++) {
                if (conceptorslist.get(j).getNode1().toString().startsWith("$") || conceptorslist.get(i).getNode1().toString().startsWith("$")) {
                    if (CompareTwoArrays(conceptorslist.get(i).receptors, conceptorslist.get(j).receptors) && !conceptorslist.get(i).getNode1().equals(conceptorslist.get(j).getNode1())) {
                        String conceptor1 = conceptorslist.get(i).getNode1().toString();
                        String conceptor2 = conceptorslist.get(j).getNode1().toString();

                        Integer intConceptor1 = tryParse(conceptor1.substring(1));
                        Integer intConceptor2 = tryParse(conceptor2.substring(1));

                        if ((conceptor1.startsWith("$")) && (conceptor2.startsWith("$"))) {
                            if (intConceptor1 > intConceptor2) {
                                // conceptors.values().removeIf(v -> v.equals(conceptor1));
                                stringsToDelete.put(conceptor1, conceptor2);
                                System.out.println("conceptor1 : " + conceptor1 + " equals : " + conceptor2);
                            } else {
                                //conceptors.values().removeIf(v -> v.equals(conceptor2));
                                stringsToDelete.put(conceptor2, conceptor1);
                                System.out.println("conceptor2 : " + conceptor2 + " equals : " + conceptor1);
                            }
                        } else if ((conceptor1.startsWith("$")) && (!conceptor2.startsWith("$"))) {
                            //conceptors.values().removeIf(v -> v.equals(conceptor2));
                            stringsToDelete.put(conceptor1, conceptor2);
                        } else if ((conceptor2.startsWith("$")) && (!conceptor1.startsWith("$"))) {
                            stringsToDelete.put(conceptor2, conceptor1);
                        }

                    }
                }
            }
        }

        for (Conceptor conc : conceptorslist) {
            nodeslist.get(conc.node1).setReceptors(conc.receptors);
        }

        ArrayList<Edge> edgeslist = new ArrayList<>();
        NetReader.readEdges(edgeslist, "Edge");

        ArrayList<Edge> edgesForNewConceptorsList = new ArrayList<>();
        NetReader.readEdges(edgesForNewConceptorsList, "Edge1");

        ArrayList<Conceptor> newConceptorList = new ArrayList<>();

        for (Conceptor conceptor : conceptorslist) {
            if (stringsToDelete.containsKey(conceptor.getNode1()) || stringsToDelete.containsKey(conceptor.getNode2())) {
                for (Conceptor conceptor2 : conceptorslist) {
                    if (!conceptor2.getNode2().equals(conceptor.getNode2()) && conceptor2.getNode1().equals(conceptor.getNode1())) {
                        conceptor.setNode1(stringsToDelete.get(conceptor.getNode1()));
                        conceptor2.setNode1(stringsToDelete.get(conceptor2.getNode1()));

                        newConceptorList.add(conceptor);
                        newConceptorList.add(conceptor2);
                    }

                    if (conceptor2.getNode2().equals(conceptor.getNode2()) && !conceptor2.getNode1().equals(conceptor.getNode1())) {
                        conceptor.setNode2(stringsToDelete.get(conceptor.getNode2()));
                        conceptor2.setNode2(stringsToDelete.get(conceptor2.getNode2()));

                        newConceptorList.add(conceptor);
                        newConceptorList.add(conceptor2);
                    }
                    break;
                }
            } else {
                newConceptorList.add(conceptor);
            }
        }

        ArrayList<Edge> newEdgesForNewConceptorsList = new ArrayList<>();

        for (Edge edgeForNewConceptors : edgesForNewConceptorsList) {
            if (stringsToDelete.containsKey(edgeForNewConceptors.getNode1()) || stringsToDelete.containsKey(edgeForNewConceptors.getNode2())) {
                for (Edge edgeForNewConceptors2 : edgesForNewConceptorsList) {
                    if (!edgeForNewConceptors2.getNode2().equals(edgeForNewConceptors.getNode2()) && edgeForNewConceptors2.getNode1().equals(edgeForNewConceptors.getNode1())) {
                        edgeForNewConceptors.setNode1(stringsToDelete.get(edgeForNewConceptors.getNode1()));
                        edgeForNewConceptors2.setNode1(stringsToDelete.get(edgeForNewConceptors.getNode1()));

                        newEdgesForNewConceptorsList.add(edgeForNewConceptors);
                        newEdgesForNewConceptorsList.add(edgeForNewConceptors2);
                    }

                    if (edgeForNewConceptors2.getNode2().equals(edgeForNewConceptors.getNode2()) && !edgeForNewConceptors2.getNode1().equals(edgeForNewConceptors.getNode1())) {
                        edgeForNewConceptors.setNode2(stringsToDelete.get(edgeForNewConceptors.getNode2()));
                        edgeForNewConceptors2.setNode2(stringsToDelete.get(edgeForNewConceptors.getNode2()));

                        newEdgesForNewConceptorsList.add(edgeForNewConceptors);
                        newEdgesForNewConceptorsList.add(edgeForNewConceptors2);

                        break;
                    }

                    break;
                }
            } else {
                newEdgesForNewConceptorsList.add(edgeForNewConceptors);
            }
        }

        ArrayList<Edge> newEdges = new ArrayList<>();

        for (Edge edge : edgeslist) {
            if (stringsToDelete.containsKey(edge.getNode2())) {
                for (Edge edge2 : edgeslist) {
                    if (edge2.getNode2().equals(edge.getNode2()) &&
                            !edge2.getNode1().equals(edge.getNode1())) {

                        edge.setNode2(stringsToDelete.get(edge.getNode2()));
                        edge2.setNode2(stringsToDelete.get(edge2.getNode2()));

                        newEdges.add(edge);
                        newEdges.add(edge2);
                        break;
                    }
                }
            } else {
                newEdges.add(edge);
            }
        }

        List<NetNode> newNetNodeList = new ArrayList<>();

        for (NetNode node : nodeslist.values()) {
            if (!stringsToDelete.containsKey(node.node_name)) {
                newNetNodeList.add(node);
            }
        }

        for (Edge edge : edgeslist) {
            NetNode node = nodeslist.get(edge.getNode1());
            NetNode node2 = nodeslist.get(edge.getNode1());

            if (node != null && node2 != null) {
                if (node2.nClass.equals("")) {
                    if (!node.conceptorList.contains(node2) && !node.node_name.equals(node2.node_name)) {
                        // node.upperNodeSet.add(node2);
                        node.conceptorList.add(node2);
                    }
                }
                if (!node2.getDownNodeSet().contains(node) && !node.node_name.equals(node2.node_name)) {
                    node2.getDownNodeSet().add(node);
                }

            }
        }

        for (Conceptor conceptor : conceptorslist) {
            NetNode node = nodeslist.get(conceptor.getNode1());
            NetNode node2 = nodeslist.get(conceptor.getNode1());

            if (node != null && node2 != null) {
                if (!conceptor.node1.startsWith("$")) {
                    if (!node.upperNodeSet.contains(node2) && !node.node_name.equals(node2.node_name)) {
                        node.upperNodeSet.add(node2);
                    }
                }

                if (node.nClass.equals("")) {
                    if (!node.receptorList.contains(node2) && !node.node_name.equals(node2.node_name)) {
                        node.receptorList.add(node2);
                    }
                }
            }
        }

        Indexer nodeList = new Indexer();

        for (NetNode node : newNetNodeList) {
            int level = node.receptorList.size();

            nodeList.AddNode(level, node);
        }


        //----------step 2 --------//
        Indexer newNodeList = processNetworkStep2(nodeList);
        //TODO update edges and write to file
        //Updating edges

        String lastEdgeName = edgesForNewConceptorsList.get(edgesForNewConceptorsList.size() - 1).getEdgeName();

        Integer edgeNameCounter = tryParse(lastEdgeName.substring(lastEdgeName.length() - 3));

        if (edgeNameCounter == null){

            edgeNameCounter = 400 + (int)(Math.random() * 1000);
        }else{
            edgeNameCounter++;
        }

        ArrayList<Edge> updatedEdges = new ArrayList<>();
        for (int i = 1; i <= newNodeList.getLastIndex(); i++) {
            if (newNodeList.GetListOfNodesByLevels(i) != null) {
                for (NetNode currentNode : newNodeList.GetListOfNodesByLevels(i)) {
                    for (NetNode downNode : currentNode.getDownNodeSet()) {
                        updatedEdges.add(
                                new Edge(randomUUID().toString().replace("-", "").substring(0, 12),
                                        downNode.getNodeName(),
                                        currentNode.getNodeName(),
                                        "link_" + edgeNameCounter++));
                    }
                    for (NetNode upperNode : currentNode.getUpperNodeSet()) {
                        updatedEdges.add(new Edge(
                                randomUUID().toString().replace("-", "").substring(0, 12),
                                currentNode.getNodeName(),
                                upperNode.getNodeName(),
                                "link_" + edgeNameCounter++));
                    }
                }
            }
        }
        for (Edge edge : updatedEdges) {
            System.out.println(edge.getNode1() + " ==> " + edge.getNode2());
        }
        String graphGuid = randomUUID().toString();
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = factory.newDocumentBuilder();

            // graph
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("newgraph");
            doc.appendChild(rootElement);
            {
                Attr attr = doc.createAttribute("nodesize");
                attr.setValue(String.valueOf(10));
                rootElement.setAttributeNode(attr);
            }
            {
                Attr attr = doc.createAttribute("vspacing");
                attr.setValue("3");
                rootElement.setAttributeNode(attr);
            }
            {
                Attr attr = doc.createAttribute("hspacing");
                attr.setValue("20");
                rootElement.setAttributeNode(attr);
            }
            {
                Attr attr = doc.createAttribute("padding");
                attr.setValue("4");
                rootElement.setAttributeNode(attr);
            }
            {
                Attr attr = doc.createAttribute("showarrows");
                attr.setValue("true");
                rootElement.setAttributeNode(attr);
            }
            {
                Attr attr = doc.createAttribute("guid");
                attr.setValue(graphGuid);
                rootElement.setAttributeNode(attr);
            }
            {
                Attr attr = doc.createAttribute("searchurl");
                attr.setValue("");
                rootElement.setAttributeNode(attr);
            }


            Element datagroups = doc.createElement("datagroups");
            rootElement.appendChild(datagroups);

            Element nodes = doc.createElement("Nodes");
            rootElement.appendChild(nodes);

            Element linkgroups = doc.createElement("Linkgroups");
            rootElement.appendChild(linkgroups);

            {
                Element groups = doc.createElement("Group");
                {
                    Attr attr = doc.createAttribute("name");
                    attr.setValue("Part_of");
                    groups.setAttributeNode(attr);
                }
                linkgroups.appendChild(groups);
            }

            for (int i = 0; i < newNetNodeList.size(); i++) {
                NetNode netNode = newNetNodeList.get(i);

                Element nodeElement = doc.createElement("Node");
                {
                    Attr attr = doc.createAttribute("guid");
                    attr.setValue(netNode.node_guid);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("nodeName");
                    attr.setValue(netNode.node_name);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("nclass");
                    attr.setValue(netNode.nClass);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("shape");
                    attr.setValue(netNode.shape);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("color");
                    attr.setValue(netNode.color);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("xPos");
                    attr.setValue(netNode.xPos);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("yPos");
                    attr.setValue(netNode.yPos);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("font");
                    attr.setValue(netNode.font);
                    nodeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("fontsize");
                    attr.setValue(netNode.fontsize);
                    nodeElement.setAttributeNode(attr);
                }
                nodes.appendChild(nodeElement);

                if (!netNode.nClass.isEmpty()) {
                    Element groups = doc.createElement("Group");
                    {
                        Attr attr = doc.createAttribute("name");
                        attr.setValue(netNode.nClass);
                        groups.setAttributeNode(attr);
                    }
                    linkgroups.appendChild(groups);
                }
            }

            Element conceptors = doc.createElement("ReceptorList");
            rootElement.appendChild(conceptors);

            for (int i = 0; i < newConceptorList.size(); i++) {
                for (int iter = 0; iter < newConceptorList.get(i).receptors.size(); iter++) {
                    Conceptor conceptor = newConceptorList.get(i);
                    Element edgeElement = doc.createElement("Conceptor");
                    {
                        Attr attr = doc.createAttribute("node1");
                        attr.setValue(conceptor.node1);
                        edgeElement.setAttributeNode(attr);
                    }
                    {
                        Attr attr = doc.createAttribute("node2");
                        attr.setValue(conceptor.receptors.get(iter).node_name);
                        edgeElement.setAttributeNode(attr);
                    }

                    conceptors.appendChild(edgeElement);
                }
            }
            //--------edges-------//
            Element edges = doc.createElement("Edges");
            rootElement.appendChild(edges);

            writeEdges(doc, rootElement, edges, newEdges);

            //--------edges-------//
            Element edgesForNewConceptors = doc.createElement("EdgesForNewConceptors");
            rootElement.appendChild(edgesForNewConceptors);

            writeEdges(doc, rootElement, edgesForNewConceptors, newEdgesForNewConceptorsList);
            writeEdges(doc, rootElement, edgesForNewConceptors, updatedEdges);
            //-----------------------------------------------------------------------//
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("files\\output.xml"));
            transformer.setOutputProperty(OutputKeys.ENCODING, "Windows-1251");
            transformer.transform(source, result);
            //--------------file record-----------//


        } catch (ParserConfigurationException | TransformerException e) {
            e.printStackTrace();
        }
        System.out.println("Finish");
    }

    private static void writeEdges(Document doc, Element rootElement, Element newElement, ArrayList<Edge> edges) {
            rootElement.appendChild(newElement);

            for (int i = 0; i < edges.size(); i++) {
                Edge edge = edges.get(i);
                Element edgeElement = doc.createElement("Edge");
                {
                    Attr attr = doc.createAttribute("guid");
                    attr.setValue(edge.guid);
                    edgeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("edgeName");
                    attr.setValue(edge.getEdgeName());
                    edgeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("node1");
                    attr.setValue(edge.getNode1());
                    edgeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("node2");
                    attr.setValue(edge.getNode2());
                    edgeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("group");
                    attr.setValue(edge.getGroup());
                    edgeElement.setAttributeNode(attr);
                }
                {
                    Attr attr = doc.createAttribute("istwoway");
                    attr.setValue(edge.getIsTwoWay());
                    edgeElement.setAttributeNode(attr);
                }
                newElement.appendChild(edgeElement);
            }
    }

    private static Indexer processNetworkStep2(Indexer indexer) {
         //STUPID SPECIFICATION

        for (NetNode node : indexer.GetListOfNodesByLevels(2)) {
            node.getDownNodeSet().addAll(node.getReceptors());
            for (NetNode receptor : node.getDownNodeSet()) {
                receptor.addUpperNode(node);
            }
        }

        //TODO: Copy indexer to localIndexer and perform remove operation with localIndexer


        for (int currentLevel = 3; currentLevel <= indexer.getLastIndex(); currentLevel++) {

            if (indexer.GetListOfNodesByLevels(currentLevel) != null) {
                for (NetNode currentNode : indexer.GetListOfNodesByLevels(currentLevel)) {
                    ArrayList<NetNode> activatedNodes = new ArrayList<>();
                    for (NetNode receptor : currentNode.getReceptors()) {
                        receptor.activate();
                        activatedNodes.add(receptor);
                    }
                    /*
                    for (NetNode node : activatedNodes) {
                        for (NetNode conceptor : node.getUpperNodeSet()) {
                            if (conceptor.getNodeLevel() <= currentLevel) {
                                conceptor.increaseActivation();
                                activatedNodes.add(conceptor);
                            }
                        }
                    }
                    */

                    for (int i = 0; i < activatedNodes.size(); i++) {
                        NetNode node = activatedNodes.get(i);
                        for (NetNode conceptor : node.getUpperNodeSet()) {
                            if (conceptor.getNodeLevel() <= currentLevel) {
                                conceptor.increaseActivation();
                                if(!activatedNodes.contains(conceptor)) {
                                    activatedNodes.add(conceptor);
                                }
                            }
                        }
                    }

                    /*
                    for (NetNode node : activatedNodes) {

                        }
                    }
                    */

                    for (int i = 0; i < activatedNodes.size(); i++) {
                        NetNode node = activatedNodes.get(i);
                        if (node.getActivationLevel() < node.getNodeLevel()) {
                            node.deactivate();
                            activatedNodes.remove(node);
                        }
                    }

                    while (activatedNodes.size() != 0) {
                        int maxlevel = 0;
                        NetNode maxActivatedNode = null;

                        for (NetNode node : activatedNodes) {
                            if (node.getActivationLevel() > maxlevel) {
                                maxlevel = node.getActivationLevel();
                                maxActivatedNode = node;
                            }
                        }

                        if(maxActivatedNode != null) {
                            if (maxActivatedNode.getDownNodeSet().size() != 0) {
                                deleteNodeSubset(maxActivatedNode, activatedNodes);
                            }
                                maxActivatedNode.deactivate();
                                activatedNodes.remove(maxActivatedNode);

                                currentNode.addDownNode(maxActivatedNode);
                                maxActivatedNode.addUpperNode(currentNode);


                        }
                    }
                }
            }
        }
        return indexer;
    }

    public static void deleteNodeSubset(NetNode node, ArrayList<NetNode> activatedNodes) {
        for (NetNode currentNode : node.getDownNodeSet()) {
            deleteNodeSubset(currentNode, activatedNodes);
            currentNode.deactivate();
            activatedNodes.remove(currentNode);
        }
    }

    public static Boolean CompareTwoArrays(ArrayList<NetNode> firstArray, ArrayList<NetNode> secondArray) {

        if (firstArray.size() != secondArray.size()) {
            return false;
        }

        for (int i = 0; i < firstArray.size(); i++) {
            if (!firstArray.get(i).node_name.equals(secondArray.get(i).node_name)) {
                return false;
            }
        }

        return true;
    }

    public static Integer tryParse(String text) {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
